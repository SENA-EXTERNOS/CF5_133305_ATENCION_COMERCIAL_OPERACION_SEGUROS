<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido
      .titulo-principal__numero
        span 2
      h1 Informe de inspección

    .row
      .col-lg-10
        .tarjeta.tarjeta--azul.p-4(
        :style="{'background-image': `url(${require('@/assets/curso/temas/tema-2/tema2-img1.png')})`}"
      )
          h3 ¿Cuál es la importancia de los informes de riesgo?
          p La inspección de riesgos es el conjunto de tareas y técnicas dirigidas a conocer y describir, las distintas características de un riesgo, que se entiende como el patrimonio expuesto.
          .cajon.bgr-tarjeta-2.p-3
            p Es una tarea netamente de observación, y el propósito de descripción que se realiza con la idea de que otras personas puedan ser las que tomen ciertas decisiones, a la vista del informe de inspección. En general, conviene tener presente la relevancia de una adecuada inspección, pues de la calidad de la primera impresión que se haya manifestado, depende el acierto que se vaya a lograr en la toma de decisiones.


    .row.justify-content-around.align-items-center.mt-5.mb-5
      .row.justify-content-around.align-items-center
        .col-lg-6.sm-10
          h2 ¿Cuál es la importancia de los informes de riesgo?
          p.mt-5 La inspección de riesgos es el conjunto de tareas y técnicas dirigidas a conocer y describir, las distintas características de un riesgo, que se entiende como el patrimonio expuesto.
          p.mt-5 Es una tarea netamente de observación, y el propósito de descripción que se realiza con la idea de que otras personas puedan ser las que tomen ciertas decisiones, a la vista del informe de inspección. En general, conviene tener presente la relevancia de una adecuada inspección, pues de la calidad de la primera impresión que se haya manifestado, depende el acierto que se vaya a lograr en la toma de decisiones. 
          p #[b Las inspecciones de riesgo las podrán llevar a cabo:] gerentes de riesgos, inspectores de compañías aseguradoras, intermediarios de seguros, técnicos en seguridad, peritos de seguros, entre otros.
 
        .col-lg-6
          figure
            img(src='@/assets/curso/temas/tema-2/tema2-img1.svg', alt='Texto que describa la imagen')
    
    separador

    #t_2_1

    .titulo-segundo.color-acento-contenido
      h2 2.1 Tipos de informes

    .row.justify-content-around.align-items-center.mt-5.mb-5
      .row.justify-content-around.align-items-center
        .col-lg-6.sm-10
          figure
            img(src='@/assets/curso/temas/tema-2/tema2-img2.svg', alt='Texto que describa la imagen')

        .col-lg-6.sm-10.mt-5
          h2 ¿Cuál es la importancia de los informes de riesgo?
          p.mt-5 En el presente contexto de crisis y de constantes cambios, se debe ser precavidos con las empresas con las que se tiene una relación comercial, para la finalidad de asegurar riesgos. Son cada vez más las empresas que están presentando impagos, que quieren contratar seguros; es por esta razón que se deben identificar y en lo posible evitar este tipo de lazos comerciales.
          p.mt-3 La cantidad de empresas que no pagan, ha aumentado de una manera notable en los últimos años, y se debe evitar que las relaciones se den con una empresa afectada por esta situación.      

    .row
      .col-lg-6.col-sm-10
        p En estos casos, más que hacer contactos con los encargados de las empresas y reuniones formales de presentación, es necesario disponer de soportes y evidencias de la realidad económica y financiera de todas las posibles empresas y clientes de las aseguradoras; es decir, con balances, estados de resultados e indicadores financieros.
        .cajon.bgr-tarjeta-2.p-3
          p.mt-3 La elaboración de los informes de riesgo se realiza con información periódica, y se presenta de manera organizada y, en muchos casos, con gráficos y tablas para un fácil entendimiento y una buena presentación. 
      .col-lg-6.col-sm-10
        figure
          img(src='@/assets/curso/temas/tema-2/tema2-img2.1.svg', alt='Texto que describa la imagen').imagen-decorativa-6
      p Estos informes traen consigo ventajas y permiten extraer información importante como se observa a continuación:
    
    .row.mt-5.justify-content-around.align-items-center
      .col-lg-4
        figure
          img(src='@/assets/curso/temas/tema-2/tema2-img3.1.svg', alt='Texto que describa la imagen').imagen-decorativa-5
      .col-lg-8
        LineaTiempoD.color-acento-contenido.justify-content-around.align-items-center
          .row(numero="1" titulo="Facilita el acceso a la financiación").justify-content-around.align-items-center
            .col-lg-2.col-sm-2.mt-3.justify-content-around.align-items-center
              figure.justify-content-around.align-items-center
                img(src='@/assets/curso/temas/tema-2/tema2-img3.svg', alt='Texto que describa la imagen').img-tarjeta-linea-1

            .col-10
              p.mt-4 Al contar con información precisa sobre los pagarés recibidos, estos se convierten, con facilidad, en liquidez para la empresa.

          .row(numero="2" titulo="Riesgo calificado y controlado")
            .col-lg-2.col-sm-10.mt-3
              figure
                img(src='@/assets/curso/temas/tema-2/tema2-img4.svg', alt='Texto que describa la imagen').img-tarjeta-linea-1

            .col-10
              p.mt-4 Con información más exacta sobre el riesgo y con un vínculo más cercano con la empresa cliente, se puede llegar a minimizar el riesgo y así tenerlo controlado.

          .row(numero="3" titulo="Evaluación de la capacidad de pago")
            .col-lg-2.col-sm-10.mt-3
              figure
                img(src='@/assets/curso/temas/tema-2/tema2-img5.svg', alt='Texto que describa la imagen').img-tarjeta-linea-1

            .col-10
              p.mt-4 Se puede identificar la solvencia y estabilidad económica de la empresa, para efectos de evitar impagos y poder sostener relaciones comerciales.

          .row(numero="4" titulo="Política de precios adaptada al riesgo del cliente")
            .col-lg-2.col-sm-10.mt-4
              figure
                img(src='@/assets/curso/temas/tema-2/tema2-img6.svg', alt='Texto que describa la imagen').img-tarjeta-linea-1

            .col-10
              p.mt-4 Cada detalle que se pueda conocer del cliente, ayuda a poder fortalecer los vínculos comerciales a la hora de evaluar la estabilidad económica del mismo. Un aspecto relevante, a tener en cuenta, es la capacidad de contar con variedad de fuentes de ingreso, es decir, que no tenga exclusivamente una sola fuente que, en caso de crisis, pudiera afectar su estabilidad.

          .row(numero="5" titulo="Valoración de la empresa ajustada a la realidad")
            .col-lg-2.col-sm-10.mt-3
              figure
                img(src='@/assets/curso/temas/tema-2/tema2-img7.svg', alt='Texto que describa la imagen').img-tarjeta-linea-1

            .col-10
              p.mt-4 Como base fundamental para establecer informes sobre los riesgos ajustados a la realidad, es fundamental disponer y acceder a datos de fuentes oficiales; es decir, la fiabilidad de los informes depende fuertemente de las fuentes y datos utilizados por quienes realizan los reportes.

          .row(numero="6" titulo="Empresa con solvencias y liquidez")
            .col-lg-2.col-sm-10.mt-3
              figure
                img(src='@/assets/curso/temas/tema-2/tema2-img8.svg', alt='Texto que describa la imagen').img-tarjeta-linea-1

            .col-10
              p.mt-4 Es necesario identificar la capacidad financiera de la empresa, que pueda evaluar la capacidad y voluntad de pagos y, de igual forma, la capacidad de liquidez en el corto plazo, para responder por sus obligaciones.

    separador

    #t_2_2
    
    .titulo-segundo.color-acento-contenido
      h2 2.2 Solicitud de asegurabilidad 

    .row
      p No todos los riesgos son asegurables; se debe tener en cuenta que cualquier situación adversa podría afectar a las personas pudiendo ser cubiertas por un seguro. Para que un riesgo sea asegurable es necesario que su materialización sea determinada por causas independientes y aleatorias del deseo de las partes. Es así, como existen hechos o siniestros que están por encima de las partes que lo ocasionan, y que cumplen unas condiciones para que el riesgo pueda ser asumido por una entidad de seguros. 
      p.mt-5 En este esquema se presentan las consideraciones para identificar que un riesgo sea asegurable.

    TabsB.color-acento-contenido.bgr-tarjeta-10.mt-5
      .py-4.py-md-5(titulo="Inspección inicial del riesgo" :icono="require('@/assets/curso/temas/tema-2/tema2-img9.svg')")
        .row
          .col-md-8.mb-4.mb-md-0.mt-5
            h3 Inspección inicial del riesgo
            p.mt-5 Se lleva a cabo la verificación de la información referenciada en la declaración de asegurabilidad. De manera simultánea, se revisa físicamente la persona o el bien a asegurar, lo que conlleva a la concreción de la inspección inicial del riesgo.        
          .col-md-4.justify-content-center.ml-5
            figure
              img(src='@/assets/curso/temas/tema-2/tema2-img10.svg', alt='Texto que describa la imagen').img-tarjeta-linea-1

      .py-4.py-md-5(titulo="Requisitos" :icono="require('@/assets/curso/temas/tema-2/tema2-img11.svg')")
        .row
          .col-md-8.mb-4.mb-md-0.mt-5
            h3 Requisitos 
            p Se identifican requisitos que permiten identificar los atributos de los riesgos asegurables en el sector asegurador, los cuales deben ser tenidos en cuenta ante la evaluación del riesgo, aunque no sean obligatorios. 
            p Los riegos podrán ser asegurables de acuerdo con:
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Se establece la probabilidad de ocurrencia del siniestro y, como consecuencia, se puede definir una prima justa.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Existe una cantidad de asegurados que necesitan que el seguro les pueda amparar de una específica clase de riesgo.
            
          .col-md-4
            figure
              img(src='@/assets/curso/temas/tema-2/tema2-img12.svg', alt='Texto que describa la imagen').img-tarjeta-linea-1

      .py-4.py-md-5(titulo="Condiciones" :icono="require('@/assets/curso/temas/tema-2/tema2-img13.svg')")
        .row
          .col-md-8.mb-4.mb-md-0.mt-5
            h3 Condiciones 
            p Para que un riesgo se pueda considerar asegurable, debe cumplir con las siguientes características:        
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Debe tratarse de un hecho lícito, ya que los hechos ilícitos no pueden ser objeto de seguro.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Debe referirse a la posibilidad de un acontecimiento o hecho futuro.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Debe afectar, por igual, a todas las personas o cosas sujetas al mismo riesgo.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Debe ser conocido en toda su extensión y alcance, por el asegurador.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Debe ser incierta su realización o el tiempo en que se produzca.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Debe tener la probabilidad de ocurrencia real de la situación de riesgo.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Debe ocurrir independiente de la voluntad, es decir, su ocurrencia no puede ser estimada o programada.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Debe ser susceptible de causar un perjuicio valorable en dinero.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Las posibilidades de que ocurra el acontecimiento previsto, deben de existir en semejante proporción.
            br
            <i class="fas fa-angle-right" STYLE="Color: green"></i> Teniendo en cuenta estos factores, el riesgo podrá ser considerado o no, por parte de la entidad aseguradora.
            
          .col-md-4
            figure
              img(src='@/assets/curso/temas/tema-2/tema2-img14.svg', alt='Texto que describa la imagen').img-tarjeta-linea-1

    .row.mt-5
      h3 Solicitud de asegurabilidad
      p.mt-5 Para realizar una solicitud de asegurabilidad, se debe realizar una serie de procedimientos para aprobar y aceptar la asegurabilidad de un riesgo.
      p.mt-5 Entre estas tenemos:

    .row.mt-5
      .col-sm-6.col-xl-4.mb-4.mb-xl-0
        .tarjeta.tarjeta-slide.arriba.color-acento-contenido(@mouseover="indicadorTarjetaSlide = false")
          .indicador--hover(v-if="indicadorTarjetaSlide")
          .tarjeta-slide__contenedor
            .tarjeta-slide__img(:style="{'background-image': `url(${require('@/assets/curso/temas/tema-2/tema2-img15.png')})`}")
            .tarjeta-slide__contenido.p-4.p-xl-5
              h3.text-center ¿Cuándo aplica la asegurabilidad?
              p.text-small En primera instancia, la asegurabilidad de un riesgo debe cumplir con las situaciones de que sea incierto, tenga posibilidad de ocurrir, sea concreto, sea lícito y ocurra de manera fortuita. Es de esta manera que puede ser aceptada su cobertura por parte de la aseguradora.
              p.text-small Según todas las condiciones descritas, acepta o no, la asegurabilidad del riesgo en cuestión.
            
      .col-sm-6.col-xl-4.mb-4.mb-xl-0
        .tarjeta.tarjeta-slide.arriba.color-acento-contenido(@mouseover="indicadorTarjetaSlide = false")
          .tarjeta-slide__contenedor
            .tarjeta-slide__img(:style="{'background-image': `url(${require('@/assets/curso/temas/tema-2/tema2-img16.png')})`}")
            .tarjeta-slide__contenido.p-4.p-xl-5
              h3.text-center Declaración de asegurabilidad
              p.text-small Hace referencia a la información previa que el potencial asegurado informa a la aseguradora, a través de un formato (documento impreso o descargable en PDF), sobre el riesgo que afecta o podría afectar sus intereses asegurables. En el formato deben ser diligenciadas cada una de las amenazas identificadas, que puedan afectar a la persona.

      .col-sm-6.col-xl-4.mb-4.mb-sm-0
        .tarjeta.tarjeta-slide.arriba.color-acento-contenido(@mouseover="indicadorTarjetaSlide = false")
          .tarjeta-slide__contenedor
            .tarjeta-slide__img(:style="{'background-image': `url(${require('@/assets/curso/temas/tema-2/tema2-img17.png')})`}")
            .tarjeta-slide__contenido.p-4.p-xl-5
              h3.text-center Análisis del riesgo
              p.text-small El análisis de riesgo es el resultado de un procedimiento que tendrá como resultado la decisión final de aceptar o no, la admisión y establecer el precio al tomador del seguro, en decir, es aquí donde la aseguradora se hace responsable del riesgo evaluado y este se formaliza en un contrato. 

    .row.mt-5
      p La declaración de asegurabilidad, es un documento que hará parte integral del contrato en el cual se debe consignar, con total claridad y honestidad, todos los antecedentes médicos; en caso de encontrar diferencia o que no se ajuste a la realidad, será causa de anulación y, por consiguiente, no se podrá pagar, en ningún caso, alguna indemnización.
      p.mt-5 En la siguiente infografía, se dan a conocer los pasos para diligenciar correctamente el formato de declaración de asegurabilidad:

    ImagenInfografica.mt-5
      template(v-slot:imagen)
        figure
          img(src='@/assets/curso/temas/tema-2/tema2-img18.svg', alt='Texto que describa la imagen')

      .tarjeta.color-primario.p-3(x="68%" y="17%" numero="")
        .h5.mb-2 Datos generales:
        p Se ingresan los datos generales: el código de la póliza, el NIT del tomador, el valor de la cobertura.

      .tarjeta.color-primario.p-3(x="75.5%" y="48%" numero="")
        .h5.mb-2 Datos personales:
        p Se ingresan los datos personales: apellidos, nombres, tipo de identificación y demás datos personales.

      .tarjeta.color-primario.p-3(x="68%" y="79%" numero="")
        .h5.mb-2 Datos del beneficiario:
        p Se ingresan los datos del beneficiario: quién o quiénes son los beneficiarios.
      
      .tarjeta.color-primario.p-3(x="31.8%" y="79%" numero="")
        .h5.mb-2 Declaración de asegurabilidad:
        p Se debe informar si ha padecido o le han diagnosticado alguna de las enfermedades que aparecen en el listado, se debe describir cuál, y el tiempo de aparición.
        p Asimismo, si ha tenido incapacidad u hospitalización por más de 60 días.

      .tarjeta.color-primario.p-3(x="24.3%" y="48%" numero="")
        .h5.mb-2 Seguimiento médico:
        p Se refiere a la tabla seguida del punto 4. Se debe precisar la información de las enfermedades que padece, informando el nombre del médico, la institución médica, la fecha y la causa.
      
      .tarjeta.color-primario.p-3(x="32%" y="17%" numero="")
        .h5.mb-2 Firma y huella:
        p Finalmente, debe firmar con identificación, la fecha y la huella dactilar

    .row.justify-content-around.align-items-centerrd.mt-5
      .col-10
        .tarjeta.color-secundario.p-3.mb-5
          .row.justify-content-around.align-items-center
            .col-3.col-sm-2.col-lg-1
              img(src="@/assets/curso/temas/tema-2/tema2-img19.svg")
            .col-9
              .row.justify-content-between.align-items-center
                .col.mb-3.mb-sm-0
                  h3.mb-1 Formato Declaración de asegurabilidad
                  p.text-small Para conocer el formato de declaración de asegurabilidad, lo invitamos a leer el siguiente documento:
                .col-sm-auto
                  a.boton.color-acento-botones.texto-blanco(:href="obtenerLink('/downloads/Formato Declaración de asegurabilidad.docx')" target="_blank")
                    span Descargar
                    i.fas.fa-file-download
               
              
    
    separador    

    
    #t_2_3

    .titulo-segundo.color-acento-contenido
      h2 2.3 Documentación asociada a los contratos de seguros

    .row.ampliar.fondo-tema2-1.px-5.margen-fondo-tema2-1
      .col-12

        .row.justify-content-around.align-items-center.margen-contenido-fondo-tema2-1
          .col-10
            figure
              img(src='@/assets/curso/temas/tema-2/tema2-img20.svg', alt='Texto que describa la imagen')

        .row.mt-5
          h3 Componentes de las pólizas

        .row.justify-content-around.align-items-center.mt-3
          .row.justify-content-around.align-items-center
            .col-lg-7.sm-10
              p.mt-5 En general, las pólizas, en sus estructuras, se dividen en dos componentes o condiciones: las condiciones generales y las condiciones particulares.
              h2 Condiciones generales
              p.mt-5 Hacen referencia a los textos que se incluyen en las pólizas, que contienen las regulaciones y las consideraciones propias del contrato; para establecer las condiciones generales, se debe contar mínimo con los siguientes puntos: la cobertura y el objeto asegurado, elementos de alteración o agravación del riesgo, exclusiones, declaraciones del asegurado, terminación, prima, comunicación entre las partes, y que incluyan los aspectos que permiten regular el contrato y que no sean condiciones 
            .col-lg-5.sm-10
              figure
                img(src='@/assets/curso/temas/tema-2/tema2-img21.svg', alt='Texto que describa la imagen')
            .row
              img(src='@/assets/curso/temas/tema-2/tema2-img22.svg', alt='Texto que describa la imagen').imagen-decorativa-3
    
        .row.justify-content-around.align-items-center.mt-3
          .row.justify-content-around.align-items-center
            .col-lg-5.sm-10
              figure
                img(src='@/assets/curso/temas/tema-2/tema2-img22.1.svg', alt='Texto que describa la imagen')      
            .col-lg-7.sm-10
              h5 Condiciones particulares
              p Hacen referencia a condiciones propias que por naturaleza no se expresan en las condiciones generales; en este caso, hacen referencia a elementos particulares como: requisitos de aseguramiento, especificidad de la materia asegurada, individualización de las partes del asegurado, el contratante, el asegurado y el beneficiario, ubicación de la materia asegurada, prima pactada, monto asegurado, deducibles, duración y la forma de pago.  
              .cajon.bgr-tarjeta-2.p-3
                p En general, tanto las condiciones generales como las particulares, deben ser redactadas de forma clara y de fácil entendimiento; no podrán conducir al error y deben estar contempladas dentro del marco de la ley.

        .row.mt-5
          p Para la formalización del contrato de seguro, es necesario reunir una serie de documentos y elementos adicionales, para continuar con el proceso de emisión del contrato. Entre estos se pueden observar los que siguen a continuación:

    .row.ampliar.fondo-tema2-2.px-5.margen-fondo-tema2-1
      .col-12

        .tarjeta.tarjeta--azul.p-4
          SlyderA(tipo="b")
            .row
              .col-md-5.mb-4.mb-md-0
                h4.mt-5 Solicitud
                p Es el primer contacto con la aseguradora; se refiere al documento en donde el interesado tomador, expresa la descripción del riesgo que desea contratar y es detallado, de manera precisa, de acuerdo con la información solicitada por parte de la aseguradora.

              .col-md-7
                figure
                  img(src='@/assets/curso/temas/tema-2/tema2-img23.svg', alt='Texto que describa la imagen')
            .row
              .col-md-5.mb-4.mb-md-0
                h4.mt-5 Propuesta de seguro de cotización
                p Posterior a la solicitud por parte del interesado, la aseguradora, con base en la información, analiza y valora el riesgo y además establece una cotización o propuesta de seguro, al posible tomador.

              .col-md-7
                figure
                  img(src='@/assets/curso/temas/tema-2/tema2-img24.svg', alt='Texto que describa la imagen')
            .row
              .col-md-5.mb-4.mb-md-0
                h4.mt-5 Póliza
                p Es el documento final que incluye las condiciones propias del seguro y de los bienes que serán objeto de asegurar, por la compañía aseguradora.

              .col-md-7
                figure
                  img(src='@/assets/curso/temas/tema-2/tema2-img25.svg', alt='Texto que describa la imagen')

            .row
              .col-md-5.mb-4.mb-md-0
                h4.mt-5 Certificado individual de seguro
                p Es la certificación que expide la compañía aseguradora al asegurado dentro de una póliza colectiva, explicando las condiciones.

              .col-md-7
                figure
                  img(src='@/assets/curso/temas/tema-2/tema2-img26.svg', alt='Texto que describa la imagen')

            .row
              .col-md-5.mb-4.mb-md-0
                h4.mt-5 Recibo
                p Es el soporte del pago del seguro, quedando justificado el detalle del pago de la prima.

              .col-md-7
                figure
                  img(src='@/assets/curso/temas/tema-2/tema2-img27.svg', alt='Texto que describa la imagen')

            .row
              .col-md-5.mb-4.mb-md-0
                h5.mt-5 Carta de garantía
                p Se expide cuando aún no se tiene la póliza definitiva. Es solicitada por parte del tomador, quien requiere demostrar que cuenta con un seguro y que no ha sido expedido por la aseguradora. Esta carta es una extensión provisional, como garantía de la existencia de una cobertura a solicitud del tomador.

              .col-md-7
                figure
                  img(src='@/assets/curso/temas/tema-2/tema2-img28.svg', alt='Texto que describa la imagen')

        .row.mt-5
            .col-3
              h4.mt-5 Características de un contrato
              p.mt-3 A continuación, se presentan las características o atributos que describen a los contratos:
            .col-9
              SlyderF(columnas="col-lg-6 col-xl-4")
                .tarjeta.bgr-tarjeta-5.p-4
                  .row.justify-content-center.mb-3

                  h2.text-center 1
                  p.text-center moment. Abandon the shelter of insecurity. Be bold. Greatness isn’t the height of your stature, it’s the heft of your spirit.

                .tarjeta.bgr-tarjeta-5.p-4
                  .row.justify-content-center.mb-3

                  h2.text-center 2
                  p.text-center moment. Abandon the shelter of insecurity. Be bold. Greatness isn’t the height of your stature, it’s the heft of your spirit.

                .tarjeta.bgr-tarjeta-5.p-4
                  .row.justify-content-center.mb-3

                  h2.text-center 3
                  p.text-center moment. Abandon the shelter of insecurity. Be bold. Greatness isn’t the height of your stature, it’s the heft of your spirit.
                
                .tarjeta.bgr-tarjeta-5.p-4
                  .row.justify-content-center.mb-3

                  h2.text-center 4
                  p.text-center moment. Abandon the shelter of insecurity. Be bold. Greatness isn’t the height of your stature, it’s the heft of your spirit.
              
                .tarjeta.bgr-tarjeta-5.p-4
                  .row.justify-content-center.mb-3

                  h2.text-center 5
                  p.text-center moment. Abandon the shelter of insecurity. Be bold. Greatness isn’t the height of your stature, it’s the heft of your spirit.
                
                .tarjeta.bgr-tarjeta-5.p-4
                  .row.justify-content-center.mb-3

                  h2.text-center 6
                  p.text-center moment. Abandon the shelter of insecurity. Be bold. Greatness isn’t the height of your stature, it’s the heft of your spirit.
                
                .tarjeta.bgr-tarjeta-5.p-4
                  .row.justify-content-center.mb-3

                  h2.text-center 7
                  p.text-center moment. Abandon the shelter of insecurity. Be bold. Greatness isn’t the height of your stature, it’s the heft of your spirit.
                
                .tarjeta.bgr-tarjeta-5.p-4
                  .row.justify-content-center.mb-3

                  h2.text-center 8
                  p.text-center moment. Abandon the shelter of insecurity. Be bold. Greatness isn’t the height of your stature, it’s the heft of your spirit.
                
                .tarjeta.bgr-tarjeta-5.p-4
                  .row.justify-content-center.mb-3

                  h2.text-center 9
                  p.text-center moment. Abandon the shelter of insecurity. Be bold. Greatness isn’t the height of your stature, it’s the heft of your spirit.


</template>

<script>
export default {
  name: 'Tema2',
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
