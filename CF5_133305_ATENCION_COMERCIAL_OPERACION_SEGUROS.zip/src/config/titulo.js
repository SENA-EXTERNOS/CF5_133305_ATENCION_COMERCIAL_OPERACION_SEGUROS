module.exports = 'Manuales de suscripción, inspección y elaboración de informes'
